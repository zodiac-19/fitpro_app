# Fitpro

Expo (React Native, JavaScript) fitness app: onboarding with body scan, anatomy map, weekly Push/Pull/Legs
log, calorie tracking, goals linked to training and food, and a live two-user Squad comparison.
Languages: English, Arabic (RTL), French, Spanish. Dark theme.

## 1. Install
```bash
npm install
npx expo install --fix     # aligns every dependency with your Expo SDK
```
Put real images in `assets/`: `icon.png` (1024x1024), `adaptive-icon.png`, `splash.png`.

## 2. Squad backend (Firebase)
Squad links two users by an invite code, so it needs a backend.
1. Create a Firebase project. Enable **Authentication → Anonymous** and **Firestore**.
2. Publish `firestore.rules` (Firestore → Rules). Only linked friends can read each other's profile.
3. Copy `.env.example` to `.env` and fill the `EXPO_PUBLIC_FIREBASE_*` values.
Without these keys the app runs normally and the Squad tab shows a setup message.

Privacy: a linked friend can see your name, age, weight, height, body fat, muscle scores, lifts, week and goals.
Add a privacy policy before publishing and consider per-item sharing toggles.

## 3. Optional servers
- `EXPO_PUBLIC_SCAN_URL`: real body analysis (contract in `src/services/bodyScan.js`). Without it the scan is a formula estimate, labelled as such.
- `EXPO_PUBLIC_VERIFY_URL`: photo verification (contract in `src/services/verification.js`). Without it the photo goal cannot be verified, and the app says so.

## 4. Run
```bash
npx expo start
```
Camera and Firebase auth work best on a development build: `npx eas build -p android --profile preview`.

## 5. Build for Google Play
```bash
npm i -g eas-cli
eas login && eas init
eas secret:create        # or add EXPO_PUBLIC_* vars in the EAS dashboard
eas build -p android --profile production   # produces an .aab
eas submit -p android
```
Change `android.package` in `app.config.js` first.

## Structure
```
App.js                      navigation + root
src/context/AppContext.js   state, reducer, persistence, weekly reset
src/utils/fitness.js        scoring, calories, goals (pure functions)
src/services/               bodyScan, verification, firebase, squadService
src/hooks/useSquad.js       identity, invite code, publishing, live friends
src/screens/                Onboarding, Home, Plan, Goals, Squad
src/components/             UI primitives, MuscleMap (SVG, front/back)
src/i18n/                   strings (en/ar/fr/es) + useI18n
```
